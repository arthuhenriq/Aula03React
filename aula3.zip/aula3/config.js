'use strict';

const dotenv = require('dotenv');

dotenv.config();

const {
    PORT,
    myPORT,
    myHOST,
    myDATABASE,
    myUSER,
    myPASSWORD,
} = process.env;

module.exports = {
    port: PORT,
    port_mysql: myPORT,
    host: myHOST,
    database: myDATABASE,
    user: myUSER,
    password: myPASSWORD,
}

